Creates a random image with information on image displaying such as author.
