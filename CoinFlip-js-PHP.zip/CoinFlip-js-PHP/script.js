let headCount = 0;
let flipCount = 0;

const container = document.getElementById("coinContainer");

while (headCount < 3) {

    let flip = Math.floor(Math.random() * 2);

    flipCount++;

    let coin = document.createElement("div");
    coin.className = "coin";

    if (flip === 1) {
        headCount++;
        coin.textContent = "H";
    } 
    else {
        headCount = 0;
        coin.textContent = "T";
    }

    container.appendChild(coin);
}

document.getElementById("result").textContent =
"It took " + flipCount + " flips!";